import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        boolean validInput = false;
        int people = 0;
        System.out.println("How many people are in the room?");
        while (!validInput) {
            try {
                Scanner scanner = new Scanner(System.in);
                people = scanner.nextInt();
                validInput = true;
            } catch (InputMismatchException exception) {
                System.out.println("Please input a valid number.");
            }
        }
        System.out.println("If everyone shakes hands once, there will be " + handshake(people) + " handshakes.");

        System.out.println();

        validInput = false;
        int n = 0;
        System.out.println("Enter value for n:");
        while (!validInput) {
            try {
                Scanner scanner = new Scanner(System.in);
                n = scanner.nextInt();
                validInput = true;
            } catch (InputMismatchException exception) {
                System.out.println("Please input a valid value.");
            }
        }

        validInput = false;
        int r = 0;
        System.out.println("Enter value for r:");
        while (!validInput) {
            try {
                Scanner scanner = new Scanner(System.in);
                r = scanner.nextInt();
                if (r >= n) {
                    throw new InputMismatchException();
                }
                validInput = true;
            } catch (InputMismatchException exception) {
                System.out.println("Please input a valid value.");
            }
        }
        System.out.println("There are " + combination(n, r) + " possible combinations.");


    }

    public static int handshake(int n) {
        if (n > 0) {
            int total = (n - 1);
            return (total + handshake(n - 1));
        } else {
            return 0;
        }
    }

    public static int combination(int n, int r) {
        int numerator = handleFactorial(n);
        int denominatorFirst = handleFactorial(r);
        int denominatorSecond = handleFactorial(n - r);
        return (numerator / (denominatorFirst * denominatorSecond));

    }

    public static int handleFactorial(int x) {
        if (x > 1) {
            return (x * handleFactorial(x - 1));
        } else {
            return x;
        }
    }
}